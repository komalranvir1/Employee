package com.Komal.Employee.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ContactDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long phoneNO;
	private Long primaryEmergencyContact;
	private Long secondaryEmergencyContact;
	
	public ContactDetails() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPhoneNO() {
		return phoneNO;
	}

	public void setPhoneNO(Long phoneNO) {
		this.phoneNO = phoneNO;
	}

	public Long getPrimaryEmergencyContact() {
		return primaryEmergencyContact;
	}

	public void setPrimaryEmergencyContact(Long primaryEmergencyContact) {
		this.primaryEmergencyContact = primaryEmergencyContact;
	}

	public Long getSecondaryEmergencyContact() {
		return secondaryEmergencyContact;
	}

	public void setSecondaryEmergencyContact(Long secondaryEmergencyContact) {
		this.secondaryEmergencyContact = secondaryEmergencyContact;
	}

	public ContactDetails(Long phoneNO, Long primaryEmergencyContact, Long secondaryEmergencyContact) {
		super();
		this.phoneNO = phoneNO;
		this.primaryEmergencyContact = primaryEmergencyContact;
		this.secondaryEmergencyContact = secondaryEmergencyContact;
	}
	
	

}
