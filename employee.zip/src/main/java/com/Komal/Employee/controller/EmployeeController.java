package com.Komal.Employee.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Komal.Employee.entity.Employee;
import com.Komal.Employee.repository.EmployeeRepo;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	@GetMapping("/get")
	public List<Employee> getAllEmployee() {
		return employeeRepo.findAll();
	}
	
	@GetMapping("/{id}")
	public Optional<Employee> GetBYId(@PathVariable Long id) {
		
		return employeeRepo.findById(id);
	}
	
	@GetMapping("/page")
	public Page<Employee> getEmployeePage(@RequestParam Map<String, String> param) {
		Integer page = Integer.parseInt(param.get("page"));
		Integer size = Integer.parseInt(param.get("size"));
		Pageable pagable = PageRequest.of(page, size);
		Page<Employee> employeePage = employeeRepo.findAll(pagable);

		return employeePage;

	}
	
	@PostMapping("/post")
	public Employee AddAllEmployee(@RequestBody Employee employee) {
		
		return employeeRepo.save(employee);
		
	}
	
	
	@PutMapping("/put/{id}")
	public Employee updateBYId(@PathVariable Long id, @RequestBody Employee employee) {
		
		Employee employee2= employeeRepo.findById(id).get();
		
		employee2.setEmployeeName(employee.getEmployeeName());
		employee2.setJobTitle(employee.getJobTitle());
		employee2.setEmail(employee.getEmail());
		employee2.setAddress(employee.getAddress());
		employee2.setCity(employee.getCity());
		employee2.setState(employee.getState());
		employee2.setRelationship(employee.getRelationship());
		
		return employeeRepo.save(employee2);
}
	
	@DeleteMapping("/{id}")
	public List<Employee> deleteById(@PathVariable Long id) {
		
		employeeRepo.deleteById(id);
		return employeeRepo.findAll();
	}
	

}
