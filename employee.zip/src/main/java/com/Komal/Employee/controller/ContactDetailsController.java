package com.Komal.Employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Komal.Employee.entity.ContactDetails;
import com.Komal.Employee.repository.ContactDetailsREpo;

@RestController
@RequestMapping("/contact")
public class ContactDetailsController {
	
	@Autowired
	private ContactDetailsREpo detailsREpo;
	
	
	@GetMapping("/get")
	public List<ContactDetails> getAllContact() {
		return detailsREpo.findAll();
	}
	
	@PostMapping("/post")
	public ContactDetails AddAllDEtail(@RequestBody ContactDetails details ) {
		return detailsREpo.save(details);
	}
	
	
	
	@PutMapping("/put")
	public ContactDetails UpdateById(@RequestBody ContactDetails details,@PathVariable Long id) {
		
		ContactDetails details2= detailsREpo.findById(id).get();
		details2.setPhoneNO(details.getPhoneNO());
		details2.setPrimaryEmergencyContact(details.getPrimaryEmergencyContact());
		details2.setSecondaryEmergencyContact(details.getSecondaryEmergencyContact());
		return detailsREpo.save(details);

	}
	
	@DeleteMapping("/{id}")
	public List<ContactDetails>  DeleteContact(@PathVariable Long id) {
		
		detailsREpo.deleteById(id);
		return detailsREpo.findAll();
	}

}
