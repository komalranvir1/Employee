package com.Komal.Employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Komal.Employee.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {

}
