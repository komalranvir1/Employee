package com.Komal.Employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Komal.Employee.entity.ContactDetails;

public interface ContactDetailsREpo extends JpaRepository<ContactDetails, Long> {

}
